classdef MobilityUtil 
% CONNECTION Class -  Exposes util methods for other classes
%   Developed by: Igor Amorim Silva
%   Version: 0.0.1
%   License: MIT
%   Date: 2017-06-23
%   Last Review : 2017-06-29
%
% --------------------------- PLEASE DONATE ---------------------------- 
%
properties (Access = private)
    
end


properties (Access = public)
    
end

methods

end

end